#include <stdio.h>

int main(void) {
    int a, b;

    printf("Enter value of a: ");
    scanf("%x", &a);
    printf("Enter value of b: ");
    scanf("%x", &b);

    printf("value of a: %X %x and as base 10 %d\n", a, a, a);
    printf("value of b: %X %x and as base 10 %d\n", b, b, b);
    return(0);
}
