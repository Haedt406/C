#include <stdio.h>

int main(void) {
    char serial_num;

    printf("Enter ship serial number: ");
    scanf("%c", &serial_num);

    printf("Ship type is ");
    // You can do this but you will get a warning (flag switch-bool)
    switch(serial_num == 'B' || serial_num == 'b') {
    case 1:
        printf("Battleship");
        break;
    case 0:
        printf("Not Battleship");
        break;
    default:
        printf("ERROR");
    }

/*
    switch(serial_num) {
    case 'B':
    case 'b':
        printf("Battleship");
        break;
    default:
        printf("Not a battleship");
    }
*/
    printf("\n");

    return(0);
}       
