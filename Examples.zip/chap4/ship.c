#include <stdio.h>

int main(void) {
    char serial_num;

    printf("Enter ship serial number: ");
    scanf("%c", &serial_num);

    printf("Ship type is ");
    switch(serial_num) {
    case 'B':
    case 'b':
        printf("Battleship");
        break;
    case 'C':
    case 'c':
        printf("Cruiser");
        break;
    case 'D':
    case 'd':
        printf("Destroyer");
        break;
    case 'F':
    case 'f':
        printf("Frigate");
        break;
    default:
        printf("ERROR");
    }

    printf("\n");

    return(0);
}       
