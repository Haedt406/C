#include <stdio.h>

int main(void) {
    double num;

    printf("Enter number: ");
    scanf("%lf", &num);

    switch(num) {
    case 12.5:
        printf("found it");
        break;
    default:
        printf("did not find it");
    }

    printf("\n");

    return(0);
}       
