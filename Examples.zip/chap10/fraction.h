typedef struct {
    int numer;
    int denom;
    double value;
} fraction_t;
