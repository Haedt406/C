#include <stdio.h>
#include <string.h>
#include "student.h"   // local header file that defines student data structure

typedef enum {false, true} Bool;

Student_t student_scan() {
    char first[50], last[50];

    Student_t stdnt;

    printf("Read in information for student: "); 
    scanf("%s %s %d %d %c", 
	       first, last, &stdnt.id, &stdnt.credits,
	       &stdnt.year);
    strcpy(stdnt.name, first);
    strcat(stdnt.name, " ");
    strcat(stdnt.name, last);
    printf("student's name is %s, %p\n", stdnt.name, &stdnt);
    printf("addresses %p, %p\n", &stdnt.name, &stdnt.id);
    printf("addresses %p, %p\n", &stdnt.credits, &stdnt.year);
    printf("size of stdnt %d, size of name %d\n", (int)sizeof(stdnt),
            (int)sizeof(stdnt.name));

    return(stdnt);
}

Student_t student_update_credits(Student_t st) {
    st.credits += 15;
    printf("in update, %p\n", &st);
    return st;
}

int main() {

    // able to return a data structure 
    Student_t st_read;
    printf("before student scan, st_read address is %p\n", &st_read);
    st_read = student_scan();
    printf("st_read main %p\n", &st_read);

    Student_t st_upd;
    printf("before student update, st_upd address is %p\n", &st_upd);
    st_upd = student_update_credits(st_read);

    printf("st_upd main is %p\n", &st_upd);

    printf("address of st_read name is %p; address of st_upd name is %p, %p, %p\n",
		    &st_read.name, &st_upd.name, st_read.name, st_upd.name);
    printf("st_read credits are %d; st_upd credits are %d, %p, %p\n",
		    st_read.credits, st_upd.credits, &st_read.credits, 
            &st_upd.credits);

    return(0);
}


