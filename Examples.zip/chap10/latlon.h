typedef struct {
    int degrees;
    int min;
    char dir;
} Lat_Lon_t;

typedef struct {
    Lat_Lon_t lat;
    Lat_Lon_t lon;
} Location_t;
