#include <stdio.h>
#include <string.h>
#include "student.h"   // local header file that defines student data structure

int student_equal(Student_t st1, Student_t st2) {
	// compare each element of the structure
	if (strcmp(st1.name, st2.name) == 0 &&
		st1.id == st2.id &&
        st1.credits == st2.credits &&
        st1.year == st2.year) {
        return 1;
    }
    else {
        return 0;
    }
}

int main() {


    // declaring a single student
    Student_t mac = {"mary ann cummings", 1, 115, 'j'};
    Student_t newst1,
	      newst2;

    newst1 = mac;
    newst2 = mac;
    newst2.id = 2;

    // cannot test for equality using the = operator
    if (student_equal(mac,newst1)) {
	    printf("mac and newst1 match\n");
    }
    else {
	    printf("mac and newst1 do not match\n");
    }

    if (student_equal(mac,newst2)) {
            printf("mac and newst2 match\n");
    }
    else {
            printf("mac and newst2 do not match\n");
    }
    return(0);
}


