#include <stdio.h>
int is_odd(unsigned int);

int is_even(unsigned int n) {
    if (n == 0) {
        printf("in is even with 0, returning 1\n");
        return 1;
    }
    else {
        printf("in is_even to call is_odd(%d)\n", n-1);
        return is_odd(n-1);
    }
}

int is_odd(unsigned int n) {
    if (n == 0) {
        printf("in is odd with 0, returning 0\n");
        return 0;
    }
    else {
       printf("in is_odd to call is_even(%d)\n", n-1);
       return is_even(n-1);
    }
}

int main(void) {
    printf("is 4 even? %s\n", (is_even(4) ? "yes" : "no"));

    printf("is 3 odd? %s\n", (is_odd(3) ? "yes" : "no"));
    return(0);
}

   
     
