echo "Lab 3 with exam.txt"
./lab3 < /public/lab3/exam.txt
echo -e "\nLab 3 with for_monday.txt"
./lab3 < /public/lab3/for_monday.txt
