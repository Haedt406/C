#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int *p = NULL; // insuring we can't use q incorrectly

    p = malloc(15 * sizeof(int));
    for (int i = 0; i < 15; i++) {
        *(p+i) = i+1;
    }
    
    printf("the sum is ");
    int sum = 0;
    for (int i = 0; i < 15; i++) {
        sum += *(p + i);
    }
    printf("%d\n", sum);

    return(0);
}
