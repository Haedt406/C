echo "run lab2 the first time"
./lab2
echo "running lab2 the second time"
./lab2
