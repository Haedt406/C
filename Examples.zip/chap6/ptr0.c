#include <stdio.h>
#include <string.h>

int main(void) {
    int *p;
    int *q = NULL; // insuring we can't use q incorrectly

    printf("Address in p is %p\n", p);
    *p = 15;
    printf("%d\n", *p);
    printf("About to set q's memory to 20\n");
    *q = 20;
    printf("Number put in q's memory\n");
    printf("%d\n", *q);

    return(0);
}
