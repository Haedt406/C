#include <stdio.h>

int main(void) {

    int* nums;

    nums = malloc(sizeof(int) * 3);

    printf("nums+0 %d, nums+1 %d, nums+2 %d\n", 
            *(nums), *(nums+1), *(nums+2));

    *(nums) = 1;
    *(nums+1) = 2;
    *(nums+2) = 3;

    printf("nums+0 %d, nums+1 %d, nums+2 %d\n",
             *(nums), *(nums+1), *(nums+2));

    free(nums);

    printf("nums+0 %d, nums+1 %d, nums+2 %d\n",
             *(nums), *(nums+1), *(nums+2));

    return(0);
}
