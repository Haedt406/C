#include <stdio.h>

void add_arrays(const int *a1, const int *a2, int n, int *asum) {
// equivalent to const int a1[], const int a2[], int n, int asum[]

    int i;
    for (i = 0; i < n; ++i) {
        *(asum+i) = *(a1+i) + *(a2+i);  // asum[i] = a1[i] + a2[i];
    }
    
    return;
}

int main(void) {

    int ar1[20];
    int ar2[20];
    int arsum[20];
    int i;
    int nums = 5;

    for (i = 0; i < nums; ++i) {
        *(ar1+i) = i + 1; // same thing as ar1[i]
    }

    for (i = 0; i < nums; ++i) {
        *(ar2+i) = *(ar1+i) * 20;  // same thing as ar2[i]
    }

    add_arrays(ar1, ar2, nums, arsum);

     for (i = 0; i < nums; ++i) {
        printf("arsum of %d is %d\n", i, *(arsum+i));
    }
    return(0);
}
