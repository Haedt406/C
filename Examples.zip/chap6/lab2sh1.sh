for value in {1..3}
do
    echo -e "\nrun " $value
    ./lab2
done
