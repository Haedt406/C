#include <stdio.h>

int main(void) {

    // syntax error
    // printf("Hello World);

    // runtime error
    //float a = 0.0;
    //float b = 5.0/0.0;

    // logic error
    // int c = 2 * (5 + 3);
    int c = 5 + 3 * 2;
    printf("The computed number is: %d\n",  c);
    return(0);
}
