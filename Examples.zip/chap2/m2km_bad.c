#include <stdio.h>  // header for definitions for input and output ops

#define KMS_PER_MILE 1.609 // conversion value

/* Converts a number from miles to kilometers
int main(void) {   
    double miles, // variable holds number of miles read in
           kms;   // variable holds the number of miles converted to
                  // kilometers

    // read in miles
    print("Enter the distance in miles: ");
    scanf("%lf", &miles);

    // convert miles to kilometers
    kms = KMS_PER_MILE * miles;

    // print result
    printf("That equals %lf kilometers.\n", lms);

    return(0);
}
