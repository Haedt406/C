#include <stdio.h>

int main(void) {
    int a = 11, b = 4;
    double c = a/b;
    double d = (double)a/b;
    double e = (double)a/(double)b;

    printf("c is %lf, d is %lf, e is %lf, e is %.0lf\n", c, d, e, e);
    return(0);
}
    
