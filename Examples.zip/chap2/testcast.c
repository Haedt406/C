#include <stdio.h>
#include <math.h>

int main(void) {
    double num = 3.58;

    int inum1 = pow(num, 2.0);

    int inum2 = (int)pow(num, 2.0);

    double dnum1 = pow(num, 2.0);

    printf("inum1 is %d, inum2 is %d\n", inum1, inum2);
    printf("dnum1 is %lf, dnum1 short is %.0lf\n", dnum1, dnum1);

    return 0;
}
