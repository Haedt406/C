#include <stdio.h>

void sum_n_avg(double n1, double n2, double n3,
               double *sum, double *avg) {
    *sum = n1 + n2 + n3;
    *avg = *sum/3.0;
    return;
}

int main(void) {

    double n1, n2, n3,
           sum,
           avg;

    // read in the 3 numbers
    printf("enter 3 numbers: ");
    scanf("%lf %lf %lf", &n1, &n2, &n3);

    // compute the sum and avg
    sum_n_avg(n1, n2, n3, &sum, &avg);

    // print the sum and avg
    printf("Sum is %.2lf, avg is %.2lf\n",
            sum, avg);

    return(0);
}


