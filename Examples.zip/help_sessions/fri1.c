#include <stdio.h>

void sum_n_avg(const double *nums,
               double *sum, double *avg) {
    *sum = nums[0] + nums[1] + nums[2];
    *avg = *sum/3.0;
    return;
}

int main(void) {

    double nums[3],
           sum,
           avg;

    // read in the 3 numbers
    for (int i = 0; i < 3; ++i) {
        printf("enter num%d: ", i);
        scanf("%lf", nums+i);
    }

    // compute the sum and avg
    sum_n_avg(nums, &sum, &avg);

    // print the sum and avg
    printf("Sum is %.2lf, avg is %.2lf\n",
            sum, avg);

    return(0);
}


