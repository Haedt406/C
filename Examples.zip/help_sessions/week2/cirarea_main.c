#include <stdio.h>

#define PI 3.14159

/* author: Mary Ann Cummings
 * Program to compute area of a circle given the radius
 */

int main(void) {

    double area, // area of a circle
           radius;  // radius of a circle

    printf("Enter radius: ");
    scanf("%lf", &radius);

    area = PI * radius * radius;

    printf("area of circle with radius %lf is %lf\n",
           radius,  area);
    return(0);
}
