#include <stdio.h>
#include <math.h>

#define PI 3.14159

/* author: Mary Ann Cummings
 * Program to compute area of a circle given the radius
 */

double ComputeArea(double rad) {
    
    // double area = PI * pow(rad,2.0);
    // return area;
    return PI * pow(rad, 2.0);
}

int main(void) {

    double area, // area of a circle
           radius;  // radius of a circle

    printf("Enter radius: ");
    scanf("%lf", &radius);

    area = ComputeArea(radius);

    printf("area of circle with radius %.2lf is %.2lf\n",
           radius,  area);
    return(0);
}
