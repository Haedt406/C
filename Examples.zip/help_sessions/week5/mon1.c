#include <stdio.h>

int main(void) {
    double arr[5];

    // read in numbers
    for (int i = 0; i < 5; i++) {
        scanf("%lf", &arr[i]);
    }

    // print out numbers
    for (int i = 0; i < 5; i++) {
        printf("arr[%d] is %.2lf\n", i, arr[i]);
    }
    return(0);
}

