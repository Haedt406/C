#include <stdio.h>

int ReadLetters(char arr[]) {
    int n;

    scanf("%d ", &n);

    for (int i = 0; i < n; ++i) {
        scanf("%c", &arr[i]);
    }
    return n;
}

int main(void) {

    char arr[10];
    int num;

    num = ReadLetters(arr);

    for (int i = 0; i < num; i++) {
        printf("letter is %c\n", arr[i]);
    }
    return(0);    
}
