#include <stdio.h>

int main(void) {
    typedef enum {January, February, March, April} Month;

    Month cur_month;

    printf("Enter month number: ");
    scanf("%u", &cur_month);

    switch(cur_month-1) {
    case January:
        printf("Month is January\n");
        break;
    case February:
        printf("Month is February\n");
        break;
    case March:
        printf("Month is March\n");
        break;
    case April:
        printf("Month is April\n");
        break;
    default:
        printf("ERROR: bad month\n");
    }


    return(0);
}
