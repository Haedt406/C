typedef struct {
    int id;
    char lgrade[3];
    double ngrade;
} Grade;

