#include <stdio.h>
#include <string.h>
#include "grade.h"

int main(void) {
    Grade g1;

    printf("Enter id and grade: ");
    scanf("%d %lf", &g1.id, &g1.ngrade);

    if (g1.ngrade >= 95.0) {
        strcpy(g1.lgrade, "A");
    }
    else if (g1.ngrade >= 90.0) {
        strcpy(g1.lgrade, "A-");
    }
    else if (g1.ngrade >= 85.0) {
        strcpy(g1.lgrade, "B+");
    }
    else if (g1.ngrade >= 80.0) {

        strcpy(g1.lgrade, "B");
    }
    else {

        strcpy(g1.lgrade, "F");
    }
    printf("id: %d has grade: %s\n", g1.id, g1.lgrade);

    return(0);
}



