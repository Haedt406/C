#include <stdio.h>

int main(void) {
    int id;
    char ch;
    printf("enter id: ");
    scanf("%d", &id);
    printf("enter char: ");
    // scanf(" %c", &ch);  OR
    scanf("\n%c", &ch);

    double dis = 123.45;
    printf("discount:\t$%.2lf(%%5)\n", dis);
    printf("id is %d, ch is %c\n", id, ch);
    return(0);
}
