#include <stdio.h>

int main(void) {

    int ac = 0, 
        bc = 0;

    char grade, nl; 

    do {
        printf("Enter grade (E ends it): ");
        scanf("%c%c", &grade, &nl);
        switch(grade) {
        case 'A':
        case 'a':
            ++ac;
            break;
        case 'B':
        case 'b':
            ++bc;
            break;
        default:
            break;
        }
    } while(grade != 'E' && grade != 'e');
    printf("a count is %d, b count is %d\n",
            ac, bc);
    return(0);
}
