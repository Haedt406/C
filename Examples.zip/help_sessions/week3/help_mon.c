#include <stdio.h>

int main(void) {

    int num1, num2;

    printf("Enter 2 integers: ");
    scanf("%d %d", &num1, &num2);

    printf("%d is ", num1);

    if (num1 == num2) {
        printf("equal to ");
    }
    else if (num1 < num2) {
        printf("less than ");
    }
    else if (num1 <= num2) {
        printf("less than or equal to ");
    }
    else if (num1 > num2) {
        printf("greater than ");
    }
    else if (num1 >= num2) {
        printf("greater than or equal to ");
    }
    printf("%d\n", num2);
    if (num1 != num2) {
        printf("they are not equal\n");
    }
    return(0);
   
}
