#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {

    FILE *infptr = fopen("/public/pgm1/inpa.txt", "r");

    char *lines[7];

    for (int i = 0; i < 7; i++) {
        lines[i] = malloc(sizeof(char) * 50);
        fgets(lines[i], 50, infptr);
    }

    for (int i = 0; i < 7; i++) {
        printf("The line is: %s", lines[i]);
    }
    return(0);
}
