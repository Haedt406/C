#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {

    FILE *infptr = fopen("/public/pgm1/inpa.txt", "r");
    FILE *outfptr = fopen("out.txt", "w");

    char *lines[20];

    /*
    for (int i = 0; i < 7; i++) {
        lines[i] = malloc(sizeof(char) * 50);
        fgets(lines[i], 50, infptr);
    }
    */
    int i = 0;
    do {
        lines[i] = malloc(sizeof(char) * 50);
    } while (fgets(lines[i++], 50, infptr));
    int size = i-1;

    char *result;
    unsigned char add_num1, add_num2, add_num3, add_num4;
    printf("size is %d\n", size);
    for (int i = 0; i < size; i++) {
        result = strtok(lines[i], ".");
        add_num1 = (unsigned char) atoi(result);
        // sscanf(result, "%hhu", &add_num1);
        result = strtok(NULL, ".");
        sscanf(result, "%hhu", &add_num2);
        result = strtok(NULL, ".");
        sscanf(result, "%hhu", &add_num3);
        result = strtok(NULL, ".");
        sscanf(result, "%hhu", &add_num4);
        add_num4 = (unsigned char) atoi(result);
        fprintf(outfptr, "Network %hhu with host %hhu-%hhu-%hhu\n",
                add_num1, add_num2, add_num3, add_num4);
    }
    fclose(infptr);
    fclose(outfptr);
    return(0);
}
