#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {

    FILE *infptr = fopen("/public/pgm1/inpa.txt", "r");
    FILE *outfptr = fopen("out.txt", "w");

    char *lines[20];

    /*
    for (int i = 0; i < 7; i++) {
        lines[i] = malloc(sizeof(char) * 50);
        fgets(lines[i], 50, infptr);
    }
    */
    int i = 0;
    do {
        lines[i] = malloc(sizeof(char) * 50);
    } while (fgets(lines[i++], 50, infptr));

    for (int i = 0; i < 7; i++) {
        fprintf(outfptr, "The line is: %s", lines[i]);
    }
    fclose(infptr);
    fclose(outfptr);
    return(0);
}
