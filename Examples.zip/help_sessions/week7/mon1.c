#include <stdio.h>
#include <stdlib.h>


int main(int argc, char** argv) {

    if (argc != 2) {
        printf("ERROR: wrong number of arguments\n");
        return(1);
    }

    printf("%s\n", argv[0]);

    printf("%s\n", argv[1]);

    int num = atoi(argv[1]);
    printf("result is %d\n", num+5);
    return(0);
}
