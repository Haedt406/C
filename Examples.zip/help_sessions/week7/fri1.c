#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void) {
    char *str = malloc(sizeof(char) * 25);

    printf("Enter string: ");
    scanf("%s", str);

    printf("%s starts with %c\n", 
            str, str[0]);
    return(0);
}
