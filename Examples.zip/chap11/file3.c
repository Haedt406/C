#include <stdio.h>
#include <stdlib.h>

int main() {

    FILE* fptr = fopen("numbers.txt", "r");
    if (fptr == NULL) {
        perror("Bad input file");
        exit(1);
    }

    fpos_t pos; // position in file

    int num;

    // get position in second line of input file

    for (int i = 0; i < 6; i++) {
        fscanf(fptr, "%d", &num);
        printf("num is %d\n", num);
        if (i == 0) {
            fgetpos(fptr, &pos);
        }
    }

    fsetpos(fptr, &pos);  // reset back to second line
    fscanf(fptr, "%d", &num);
    printf("back to second line, num is %d\n", num);

    // close the files
    fclose(fptr);

    return(0);
}
