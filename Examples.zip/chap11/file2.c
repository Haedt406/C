#include <stdio.h>
#include <stdlib.h>

int main(void) {
   
    FILE* fptr = fopen("out.txt", "a");
    if (fptr == NULL) {
        perror("Could not open numbers.txt for appending");
        exit(1); 
    }

    int num  = 123;
    fprintf(fptr, "num is %d\n", num);
    fclose(fptr);

    return(0);
} 
