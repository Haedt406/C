#include <stdio.h>

int main(void) {
   
    int num;
    scanf("%d", &num);
    printf("This is a test with %d\n", num);
    perror("This is an error I created through the program");
    fprintf(stderr, "This is also an error thru fprintf\n");

    return(0);
} 
