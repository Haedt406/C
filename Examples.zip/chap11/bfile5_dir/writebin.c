#include <stdio.h>
#include "grades.h"

void WriteBin(Student_t* students, int size) {

    FILE* fptr = fopen("students.bin", "wb");
    fwrite(students, sizeof(Student_t), size, fptr);
    fclose(fptr);
    return;
} 
