#include <stdio.h>
#include "grades.h"

void ReadPrintBin() {

    FILE* fptr = fopen("students.bin", "rb");

    Student_t students[50];
    int i = 0;
    while (feof(fptr) == 0) {

        fread(&students[i], sizeof(Student_t), 1, fptr);
        if (feof(fptr) == 0) {
            printf("Name: %-7s %-15sGrade: %.2lf\n",
                       students[i].first_name, students[i].last_name, 
                       students[i].grade);
        }
        ++i;
    }
    fclose(fptr);
    return;
} 
