#include <stdio.h>
#include "grades.h"

int main() {
    Student_t students[50];

    // read in the text class file and put classes in array
    int size = ReadGrades(students);

    // write array to a binary file
    WriteBin(students, size);
    // Now read the binary file and print out the students
    ReadPrintBin();
    return(0);
}
