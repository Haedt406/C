#include <stdio.h>
#include <stdlib.h>

int main(void) {
   
    FILE* fptr = fopen("numbers.txt", "r");
    if (fptr == NULL) {
        perror("Could not open numbers.txt");
        exit(1); 
    }

    int num;
    while (fscanf(fptr, "%d", &num) != EOF) {}
    
    fclose(fptr);

    printf("This is a test with %d\n", num);
    perror("This is an error I created through the program");

   FILE* fptr_err = fopen("mynum.txt", "r");
    if (fptr_err == NULL) {
        perror("Could not open numbers.txt");
        exit(1);
    }

    return(0);
} 
