#include <stdio.h>

int main(void) {
    unsigned char i1, i2, i3, i4;

    scanf("%hhu.%hhu.%hhu.%hhu", &i1, &i2, &i3, &i4);

    printf("address parts are  %d %d %d %d\n", 
                        i1, i2, i3, i4);
    return(0);
}
