#include <stdio.h>

int main(void) {
    typedef enum {Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, 
        Saturday} days_t;

    char *day_names[] = { "Sunday", "Monday", "Tuesday", "Wednesday", 
                          "Thursday", "Friday", "Saturday"};

    days_t cur_day = Monday;

    printf("Today is day %d and is %s\n", cur_day, day_names[cur_day]); 
    return(0);
}
