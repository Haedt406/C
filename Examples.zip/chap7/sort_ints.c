#include <stdio.h>

// Implements the selection sort
// algorithm

void Print(int[], int);

void SelectionSort(int arr[], int size) {
    int i, j;
    char temp;

    for (i = 0; i < size-1; i++) {
        for (j = i+1 ; j < size; j++) {
            if (arr[i] > arr[j]) {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        Print(arr, size);
    }
}

void Print(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        printf(" %d ", arr[i]);
    }
    printf("\n");
    return;
}

int main() {
    int array[100];

    int i=0;

    while (scanf("%d", &array[i]) == 1) {
        i++;
    }
    printf("i is %d\n", i);
    SelectionSort(array, i);
    
    return(0);
}
