#include <stdio.h>
#include <stdlib.h>
#define END -1 

// to run: ./search 11 < numbers.txt
int search(const int* array, int num_to_find) {
    int i = 0;
    int found = 0;

    while(!found && array[i] != END) {
        if (array[i] == num_to_find) {        
            found = 1;
        }
        else {
            ++i;
        }
    }
    return found;
}

int main(int argc, char** argv) {

    int no_read = 1,
        num,
        num_to_search,
        i,
        array[50];

    if (argc != 2) {
        printf("ERROR: need to send in the number to search on the command line\n");
    }
    for (i = 0; no_read == 1; ++i)  {
        no_read = scanf("%d", &num);
        if (no_read == 1) {
            array[i] = num; 
        }
        else {
            array[i] = END;
        }
    }

    num_to_search = atoi(argv[1]); 
    printf("%d was ", num_to_search);
    if (search(array, num_to_search)) {
        printf("found\n");
    }
    else {
        printf("not found\n");
    }

    return(0);
}
    




