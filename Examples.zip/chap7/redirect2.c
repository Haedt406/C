#include <stdio.h>

int main(void) {
    double a, b, c, d, e;

    scanf("%lf %lf %lf %lf %lf", &a, &b, &c, &d, &e);

    printf("These are great numbers and the numbers \
            are %lf, %lf, %lf, %lf, %lf\n", 
                        a, b, c, d, e);
    return(0);
}
