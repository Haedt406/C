#include <stdio.h>

typedef enum { false, true, maybe } Boolean_t;

typedef int Counter_t;

int main() {

    Boolean_t flag;

    Counter_t i;

    flag = false;

    for (i = 0; i < 5; i++) {
        if (i == 4) {
            flag = true;
        }
        printf("flag is %d\n", flag);
    }
    return(0);
}
