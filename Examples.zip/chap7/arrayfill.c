#include <stdio.h>

int main(void) {
    // taking advantage of a gnu extension
    int arr1[5] = {[0 ... 4] = 1};
    int arr2[5] = {1};

    for (int i = 0; i < 5; i++) {
        printf("index %d: arr1 %d arr2 %d\n", i, 
                arr1[i], arr2[i]);
    }
    return(0);
}

