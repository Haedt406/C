echo -e "run one for lab2"
./lab2
echo -e "\nrun two for lab2"
./lab2
