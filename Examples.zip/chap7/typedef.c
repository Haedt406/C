#include <stdio.h>

typedef int Counter_t;

int main(void) {
 
    Counter_t i;
    for (i = 0; i < 5; ++i) {
        printf("i is %d\n", i);
    }
    return(0);
}    
