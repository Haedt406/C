#include <stdio.h>

int main(void) {
    int a = 3;
    int b = 4;

    printf("Are a and b equal? %c\n", (a == b ? 'y' : 'n'));
    return(0);
}
