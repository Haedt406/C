#include <stdio.h>
#include <string.h>

int main() {
    char a[10];
    // a = "Hello";
    strcpy(a, "Hello");
    
    printf("a is %s\n", a);

    return(0);
}
