#include <stdio.h>
#include <unistd.h>

int n = 3;
int proc_num;
int i = 0;
int main(void) {
    for (int i = 0; i < n; ++i) {
         proc_num = fork();
    }
    ++i;
    printf("here %d\n", i);
    return(0);
}
