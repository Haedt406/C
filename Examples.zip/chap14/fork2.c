#include <stdio.h>
#include <unistd.h>

int main(void) {
    int x = 1;
    printf("hello\n");
    fork();
    printf("hello1, x is %d\n", x);
    x = 2;
    fork();
    printf("hello2, x is %d\n", x);
    x = 3;
    fork();
    printf("hello3, x is %d\n", x);

    return(0);
}
    
