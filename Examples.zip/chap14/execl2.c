#include <stdio.h>
#include <unistd.h>

int main(void) {
    if (fork() == 0) {  // child process
        execl("/bin/ls", "/bin/ls", NULL);
    }
    else {
        for (int i = 0; i < 10; ++i) {
            printf("I am in the parent\n");
        }
    }
    return(0);
}
