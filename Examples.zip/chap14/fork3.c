#include <stdio.h>
#include <unistd.h>

int main(void) {
    int a = 0;
    if (fork() == 0) {  // child process
        a += 5;
        printf("child %d, %p\n", a, &a);
    }
    else {
        a -= 5;
        printf("parent %d, %p\n", a, &a);
    }
    return(0);
}
