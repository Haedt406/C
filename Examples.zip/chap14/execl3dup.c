#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>

int main(void) {
    if (fork() == 0) {  // child process
        int fd;
        if ((fd = open("dup.txt", O_RDWR|O_CREAT, S_IRUSR|S_IWUSR)) != -1) {
            dup2(fd, STDOUT_FILENO);
            close(fd);
            execl("/bin/ps", "/bin/ps", "aux",  NULL);
        }
    }
    else {
        wait(NULL);
        FILE* fptr = fopen("dup.txt", "r");
        if (fptr != NULL) {
            char line[90];
            fgets(line, 90, fptr);
            printf("line is %s\n", line);
        }
        fclose(fptr);
        
    }
    return(0);
}
