#include <stdio.h>
#include <unistd.h>

// What will be the output of this program?
//
void forkexample() {
    if (fork() == 0) {
        printf("Hello from child\n");
    }
    else {
        printf("Hello from parent\n");
    }
    return;
}

int main(void) {
    forkexample();
    return(0);
}
