#include <stdio.h>
#include <unistd.h>

int glob;

void forkexample() {
    int x = 1;

    if (fork() == 0) {  // the child
        printf("Child has x = %d\n", ++x);
        glob = 7;
    }
    else {
        printf("Parent has x = %d\n", --x);
        glob = 8;
    }
    return;
}

int main(void) {
    printf("in main\n");
    glob = 5;
    forkexample();
    printf("glob %d\n", glob);
    printf("running\n");
    return(0);
}
