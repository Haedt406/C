#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <fcntl.h>

int main(void) {
    if (fork() == 0) {  // child process
        int fd;
        // This function makes a system call to open a file
        if  ((fd = open("out.txt", O_RDWR|O_CREAT,S_IRUSR|S_IWUSR)) == -1) {
            perror("Error: could not open\n");
            exit(1);
        }
        // create a copy of the file descriptor for out.txt and uses STDOUT as its file descriptor
        // In other words, STDOUT and STDERR now get written to out.txt
        dup2(fd, STDOUT_FILENO);
        // We don't need that file descriptor any more so close it and this will prevent 
        // leaks to the parent process
        close(fd);
        execl("/bin/ls", "/bin/ls", "-l", NULL);
    }
    else {
        wait(NULL);
        FILE* fptr = fopen("out.txt", "r");
        if (fptr == NULL) {
            printf("bad file pointer\n");
        }
        char* line = malloc(sizeof(char) * 100);
        while (fgets(line, 100, fptr) != NULL) {
            printf("it is %s", line);
        }
    }
    return(0);
}
