#include <stdio.h>
#include <unistd.h>

int main(void) {
    printf("before call to execl\n");
    execl("/bin/ls", "/bin/ls", NULL);

    // will never get here
    printf("after call to execl\n");
    return(0);
}
