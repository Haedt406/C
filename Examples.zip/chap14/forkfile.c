#include <stdio.h>
#include <unistd.h>


void forkexample(FILE* fptr) {

    int num;
    if (fork() == 0) {  // the child
        for (int i = 0; i < 3; i++) {
            fscanf(fptr, "%d", &num);
            printf("child, num is %d\n", num);
        }
    }
    else {
       for (int i = 0; i < 3; i++) {
            fscanf(fptr, "%d", &num);
            printf("parent, num is %d\n", num);
        }
    }
    return;
}

int main(void) {
    printf("in main\n");
    FILE* fptr = fopen("numbers.txt", "r");
    forkexample(fptr);
    // fclose(fptr);
    return(0);
}
