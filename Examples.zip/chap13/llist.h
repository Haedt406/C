
typedef struct {
    int num1;
    int num2;
} Data_t;

typedef struct node_t {
    Data_t* data;
    struct node_t *next;
} Node_t;


