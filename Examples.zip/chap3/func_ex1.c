#include <stdio.h>

int f(int x) {
    int y = x * x;
    return y;
}

int main() {
    int y;
    y = f(5);
    printf("5 squared is %d\n", y);
    y = f(2);
    printf("2 squared is %d\n", y);
    return(0);
}
